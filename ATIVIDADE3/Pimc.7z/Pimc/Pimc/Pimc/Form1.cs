﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pimc
{
    public partial class Form1 : Form
    {
        double peso, altura, imc;
        string resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void txtPeso_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtPeso.Text, out peso)
                || (peso <= 0))
                {
                MessageBox.Show("Peso Inválido!");
                txtPeso.Focus();
            }
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtPeso.Clear();
            txtAlt.Clear();
            txtResult.Clear();
        }

        private void txtAlt_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtAlt.Text, out altura)
            || (altura <= 0))
                {
                MessageBox.Show("Altura Inválida1!");
                txtAlt.Focus();
            }
        }

        private void BtnCalc_Click(object sender, EventArgs e)
        {
            imc = peso / (Math.Pow(altura,2));
            imc = Math.Round(imc, 1);
            if (imc < 18.5)
            {
                txtResult.Text = imc + " Magreza";
            }
            else if (imc < 25)
            {
                txtResult.Text = "Normal";
            }
            else if (imc < 30)
            {
                txtResult.Text = "Sobrepeso";
            }
            else if (imc < 40)
            {
                txtResult.Text = "Obesidade";
            }
            else
            {
                txtResult.Text = "Obesidade Grave";
            }

        }
    }
}
